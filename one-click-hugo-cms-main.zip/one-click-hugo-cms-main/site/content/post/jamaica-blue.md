---
title: 'LEAVE NO WOMAN OR GIRL BEHIND'
date: 2022-11-02T15:04:10.000Z
description: >-
  Achieving universal, high-quality education for all girls remains out of reach
  
---
Decades of research leave no doubt about the direct and indirect benefits of educating girls and young women, which include faster poverty reduction, better maternal health, lower child mortality, greater HIV prevention and reduced violence against women.
Girls’ right to education is integral to virtually every aspect of development, including economic growth and prosperity. Each additional year of schooling can boost a girl’s earnings as an adult by up to 20 per cent.

## In Focus

Globally, transformative gains in girls’ education have unfolded in recent decades. Girls’ learning outcomes have, on average, caught up to those of boys and in some cases surpassed them. But for girls from the poorest households and in rural areas, the trajectory has not been equal or transformative. 
A sample of 29 countries with recent data on upper secondary school completion by sex, location and 

## The path for girls

The path for girls facing discrimination based on race, ethnicity, religion, migration status and/or disability likewise diverges from the aggregate.
Data from 42 countries found that children with disabilities had less access to early childhood education than children without disabilities. 
The disparity was greater for girls with disabilities. Only 18 per cent of girls with one or more functioning difficulties attended an early childhood education
programme compared to 28 per cent of girls without functional difficulties. 

Pandemic-related disruptions to education systems further exacerbated access and deepened learning inequalities for vulnerable groups of girls and young women.
