// JS Goes here - ES6 supported

import "./css/main.scss";

// Say hello
console.log("🦊 Hello! Edit me in src/index.js");
